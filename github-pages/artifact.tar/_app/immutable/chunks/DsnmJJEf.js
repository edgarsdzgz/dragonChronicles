typeof window<"u"&&((window.__svelte??={}).v??=new Set).add("5");
